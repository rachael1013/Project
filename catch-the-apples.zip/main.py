from tkinter import *
from math import *
from time import *
from random import *

root = Tk()
s = Canvas(root, width=700, height=500, background="lightblue")


def setInitialValues():
    #Declare global variables.
    global score,startTime,gameClock

    global basketImageFile,xBasket,yBasket,xSpeed,appleImageFile,numApples,numPoisonous,poisonousAppleImageFile,totalApples,goldenAppleImageFile,numGolden

    #Give each global variable an initial value
    score = 0
    startTime = 0
    gameClock = 30

    basketImageFile = PhotoImage(file="kisspng-oval-basket-emoji-picnic-baskets-wicker-5cfda1b297b5a6.7063394815601258746214 (1).png")
    appleImageFile = PhotoImage(file="NicePng_red-apple-png_1536732 (2).png")
    poisonousAppleImageFile = PhotoImage(file="applep.png")
    goldenAppleImageFile = PhotoImage(file="PngItem_2940020 (3).png")

    xBasket = 300
    yBasket = 400
    xSpeed = 0 

    numApples = 4
    numPoisonous = 2
    numGolden = 1
    totalApples = numApples+numPoisonous+numGolden


def keyDownHandler (event):
  global xSpeed
  if event.keysym == "Left":
    xSpeed = -8
  
  elif event.keysym == "Right":
    xSpeed = 8

def keyUpHandler( event ):
  global xSpeed
  xSpeed = 0


def getDistance(x1, y1, x2, y2):
  dist = sqrt( (x2 - x1)**2 + (y2-y1)**2 )
  return dist


def background():
  #SKY AND GRASS
  s.create_rectangle(0,400,700,700,fill="palegreen2",outline="palegreen2")
  
  #SCORE
  s.create_text(340,50,text="SCORE",font = "Helvetica 16 bold italic", fill = "black")
  scoreText = s.create_text( 330,100, text = score, font = "Helvetica 42 bold italic", fill = "black" )

def createApples():
  global xApple,yApple,yAppleSpeed,appleImage,imageType

  xApple=[]
  yApple=[]
  yAppleSpeed=[]
  appleImage=[]
  imageType = []

  for i in range(numGolden):
    xApple.append(randint(1,700))
    yApple.append(randint(-1000,-800))

    yAppleSpeed.append(10)
    appleImage.append(0)
    imageType.append("golden")

    for i in range(numPoisonous):
      xApple.append(randint(1,700))
      yApple.append(randint(-1000,0))
      yAppleSpeed.append(10)
      appleImage.append(0)
      imageType.append("poisonous")


      for i in range(numApples):
        xApple.append(randint(1,700))
        yApple.append(randint(-1000,0))

        yAppleSpeed.append(10)
        appleImage.append(0)
        imageType.append("red")


def drawApples():
  global appleImage,imageType

  for i in range(totalApples):
    if imageType[i] == "red":
      appleImage[i]=s.create_image(xApple[i],yApple[i],anchor=CENTER,image=appleImageFile)
    
    elif imageType[i] == "poisonous":
      appleImage[i] = s.create_image(xApple[i],yApple[i],anchor=CENTER,image=poisonousAppleImageFile)
    
    else:
      appleImage[i] = s.create_image(xApple[i],yApple[i],anchor=CENTER,image=goldenAppleImageFile)
  

def updateApplePositions():
  global xApple,yApple,xBasket,yBasket,yAppleSpeed,appleImage,score

  for i in range(totalApples):
    yApple[i] = yApple[i]+yAppleSpeed[i]
    
    distFromBasket = getDistance(xApple[i],yApple[i],xBasket,yBasket)

    if distFromBasket <= 80:
      yApple[i] = randint(-300,-5)
      xApple[i] = randint(0,700)
      
      if imageType[i] == "red":
        score = score + 1
      
      elif imageType[i] == "poisonous":
        score = score - 3
       
      else:
        score = score + 5
       
      updateScore()

    if yApple[i] >=505:
      yApple[i] = randint(-1000,-5)
      xApple[i] = randint(0,700)
  


def drawBasket():
  global basketImage

  basketImage = s.create_image( xBasket,yBasket, anchor=CENTER, image=basketImageFile)

def updateBasketPosition():
  global xBasket,yBasket,xSpeed
  xBasket = xBasket + xSpeed


def updateScore():
  s.create_rectangle(0,0,600,400,fill="lightblue",outline="lightblue")

  s.create_text(340,50,text="SCORE",font = "Helvetica 16 bold italic", fill = "black")
  scoreText = s.create_text( 330,100, text = str(score), font = "Helvetica 42 bold italic", fill = "black" )

def updateTimer():
  global startTime,gameClock

  timeSince = time()-startTime

  if timeSince >= 1:
    gameClock = gameClock -1
    startTime = time()
    
  if gameClock == 10:
    s.create_text(340,300,text="TEN SECONDS LEFT!",font = "Helvetica 20 bold italic",fill = "black")



#ACTUAL CODE THAT RUNS GAME
def runGame():
  setInitialValues()
  background()
  createApples()

  while gameClock > 0:
    updateBasketPosition()
    updateApplePositions()
    updateTimer()
    
    drawBasket()
    drawApples()

    s.update()
    sleep(0.03)
    s.delete( basketImage)
    
    for i in range(totalApples):
      s.delete(appleImage[i])

  s.create_text( 335,350, text = "TIME'S UP!", font = "Helvetica 42 bold", fill = "black" )
    

#STARTS THE GAME 
root.after(100,runGame)

#BINDS THE SCREEN TO ALL MOUSE AND KEYBOARD EVENTS
s.bind( "<Key>", keyDownHandler)
s.bind( "<KeyRelease>", keyUpHandler)

s.pack()
s.focus_set()
root.mainloop()
